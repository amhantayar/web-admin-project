﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace UltimateTruth.Admin.Models
{
    public class MySettingsModel
    {
        public string WebApiBaseUrl { get; set; }
    }
}

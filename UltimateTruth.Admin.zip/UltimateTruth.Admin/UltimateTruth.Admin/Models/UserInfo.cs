﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace UltimateTruth.Admin.Models
{
    public class UserInfo
    {
        public string userguid { get; set; }
        public string userid { get; set; }
        public string password { get; set; }
        public string fullname { get; set; }
    }
}

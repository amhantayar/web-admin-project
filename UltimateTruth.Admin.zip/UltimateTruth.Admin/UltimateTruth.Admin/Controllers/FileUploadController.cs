﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using Amazon;
using Amazon.S3;
using Amazon.S3.Transfer;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;


namespace UltimateTruth.Admin.Controllers
{
    public class FileUploadController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
        [HttpPost]
        [ActionName("Update")]
        public async Task<IActionResult> FileUpload()
        {
            return View();
        }
        [HttpPost]
        public async Task UploadFileToS3(IFormFile file)
        {
            //Please note that if no form data is posted
            // HttpContext.Request.Form will throw an exception


            //   using (var client = new AmazonS3Client("yourAwsAccessKeyId", "yourAwsSecretAccessKey", RegionEndpoint.USEast1))
            using (var client = new AmazonS3Client("HABADP4LTXG7INMSU2ZV", "cIg90I4p87+dh8weqNFCCanqunELuj9RLX9BdXoxheQ", RegionEndpoint.USEast1))
            {

                using (var newMemoryStream = new MemoryStream())
                {
                    if (HttpContext.Request.Form.Files[0] != null)
                    {
                        file = HttpContext.Request.Form.Files[0];

                    }
                    file.CopyTo(newMemoryStream);

                    var uploadRequest = new TransferUtilityUploadRequest
                    {
                        InputStream = newMemoryStream,
                        Key = file.FileName,
                        BucketName = "amhantayar-dev",
                        CannedACL = S3CannedACL.PublicRead
                    };

                    var fileTransferUtility = new TransferUtility(client);
                    await fileTransferUtility.UploadAsync(uploadRequest);
                }
            }
        }
    }
}